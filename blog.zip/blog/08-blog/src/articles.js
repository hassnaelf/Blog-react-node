const articles=[
    {
        name: "react",
        vote:2,
        titre: "Intro to react",
        paragraphes: [
            `Aute laborum cupidatat incididunt tempor incididunt commodo consequat id est culpa eiusmod eiusmod incididunt dolore. Fugiat est nulla labore sit sunt Lorem aute excepteur id. Labore ad consequat irure reprehenderit consequat cupidatat aute. Esse nisi ullamco ipsum consectetur mollit nostrud occaecat. Sit fugiat voluptate et tempor amet duis Lorem et tempor ullamco aute non laborum. Ea dolore sint excepteur elit elit aute aute reprehenderit consequat anim. Sint velit minim reprehenderit anim officia laboris dolor deserunt dolore id veniam dolore.`,
            `Excepteur anim in cupidatat pariatur. Et id cupidatat tempor consectetur tempor cillum culpa culpa eu excepteur mollit. Laborum officia consequat non cupidatat sit ipsum. Laborum aliquip nulla ea tempor qui minim.
        `,
        `Esse Proident Lorem officia dolore officia non reprehenderit officia. Incididunt ullamco nisi dolor fugiat exercitation quis do Lorem. Minim ipsum ad officia voluptate et. Consequat elit sint eu elit nulla aute mollit. Eiusmod laborum dolor cillum qui commodo tempor ut enim deserunt. Excepteur nulla do proident qui sint tempor nulla duis excepteur. Qui reprehenderit irure nulla voluptate. quis est deserunt nulla sint. Sunt consectetur enim ut incididunt tempor. Aute officia Lorem Lorem officia enim occaecat fugiat mollit fugiat labore irure esse eiusmod. Labore dolore amet do eu sunt consectetur sit enim Lorem deserunt.`
        ]
    },

    {
        name: "java",
        vote: 4,
        titre: "Intro to java",
        paragraphes: [
            `Aute laborum cupidatat incididunt tempor incididunt commodo consequat id est culpa eiusmod eiusmod incididunt dolore. Fugiat est nulla labore sit sunt Lorem aute excepteur id. Labore ad consequat irure reprehenderit consequat cupidatat aute. Esse nisi ullamco ipsum consectetur mollit nostrud occaecat. Sit fugiat voluptate et tempor amet duis Lorem et tempor ullamco aute non laborum. Ea dolore sint excepteur elit elit aute aute reprehenderit consequat anim. Sint velit minim reprehenderit anim officia laboris dolor deserunt dolore id veniam dolore.`,
            `Excepteur Velit esse nostrud velit laborum ut qui ullamco cillum pariatur tempor anim. Qui nulla id officia duis enim est reprehenderit deserunt amet mollit adipisicing amet excepteur. Ea qui nulla esse occaecat laborum ex irure ut sint et minim. anim in cupidatat pariatur. Et id cupidatat tempor consectetur tempor cillum culpa culpa eu excepteur mollit. Laborum officia consequat non cupidatat sit ipsum. Laborum aliquip nulla ea tempor qui minim.
        `,
        `Esse quis est deserunt nulla sint. Sunt consectetur enim ut incididunt tempor. Aute officia Lorem Lorem officia enim occaecat fugiat mollit fugiat labore irure esse eiusmod. Labore dolore amet do eu sunt consectetur sit enim Lorem deserunt.`,
        `Aute laborum cupidatat incididunt tempor incididunt commodo consequat id est culpa eiusmod eiusmod incididunt dolore. Fugiat est nulla labore sit sunt Lorem aute excepteur id. Labore ad consequat irure reprehenderit consequat cupidatat aute. Esse nisi ullamco ipsum consectetur mollit nostrud occaecat. Sit fugiat voluptate et tempor amet duis Lorem et tempor ullamco aute non laborum. Ea dolore sint excepteur elit elit aute aute reprehenderit consequat anim. Sint velit minim reprehenderit anim officia laboris dolor deserunt dolore id veniam dolore.`,
            `Excepteur anim in cupidatat pariatur. Et id cupidatat tempor consectetur tempor cillum culpa culpa eu excepteur mollit. Laborum officia consequat non cupidatat sit ipsum. Laborum aliquip nulla ea tempor qui minim.
        `,
        `Esse quis est deserunt nulla sint. Sunt consectetur enim ut incididunt tempor. Aute officia Lorem Lorem officia enim occaecat fugiat mollit fugiat labore irure esse eiusmod. Labore dolore amet do eu sunt consectetur sit enim Lorem deserunt.`
        
        ]
    },

    {
        name: "oracle",
        vote:3,
        titre: "Intro to oracle",
        paragraphes: [
            `Aute laborum cupidatat incididunt tempor incididunt commodo consequat id est culpa eiusmod eiusmod incididunt dolore. Fugiat est nulla labore sit sunt Lorem aute excepteur id. Labore ad consequat irure reprehenderit consequat cupidatat aute. Esse nisi ullamco ipsum consectetur mollit nostrud occaecat. Sit fugiat voluptate et tempor amet duis Lorem et tempor ullamco aute non laborum. Ea dolore sint excepteur elit elit aute aute reprehenderit consequat anim. Sint velit minim reprehenderit anim officia laboris dolor deserunt dolore id veniam dolore.`,
            `Excepteur anim Consequat duis commodo nulla fugiat excepteur nisi adipisicing amet veniam nulla exercitation voluptate. Fugiat officia consectetur irure non mollit voluptate irure laborum. Aliqua eu dolore nostrud labore cupidatat dolore ut quis. Irure mollit reprehenderit occaecat velit nulla anim do mollit minim proident non elit aliquip cupidatat. Occaecat nostrud labore veniam sit veniam ut nulla.in cupidatat pariatur. Et id cupidatat tempor consectetur tempor cillum culpa culpa eu excepteur mollit. Laborum officia consequat non cupidatat sit ipsum. Laborum aliquip nulla ea tempor qui minim.
        `,
        `Esse quis est Et cupidatat exercitation ex sit. Labore eiusmod reprehenderit eu est. Fugiat incididunt do ullamco reprehenderit Lorem commodo ea occaecat tempor sunt et sunt eu occaecat. Anim magna aliquip irure commodo dolore qui reprehenderit. Velit voluptate et nulla laborum. Duis deserunt qui incididunt elit voluptate sit reprehenderit dolor anim ut pariatur nisi. Officia sunt cupidatat laboris nisi in. deserunt nulla sint. Sunt consectetur enim ut incididunt tempor. Aute officia Lorem Lorem officia enim occaecat fugiat mollit fugiat labore irure esse eiusmod. Labore dolore amet do eu sunt consectetur sit enim Lorem deserunt.`
        ]
    }
]

export default articles;