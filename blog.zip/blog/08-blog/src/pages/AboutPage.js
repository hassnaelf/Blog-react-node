import React, { Component } from "react";

class AboutPage extends Component {
    render() {
        return ( 
            <div >
            <h1> About page </h1> 
            <p>Esse ut voluptate deserunt cupidatat officia qui eu. Non sit adipisicing non voluptate do sit Lorem ea exercitation aute. In duis aute ad incididunt do fugiat. Sit ea officia aute tempor ad anim veniam tempor eiusmod adipisicing dolore deserunt.</p>
            <p>Id mollit ipsum exercitation consectetur duis. Deserunt aute mollit id ullamco consectetur aliqua laborum eu laborum non pariatur. Irure officia cillum minim consequat minim cillum ipsum minim anim proident veniam fugiat ut.</p>
            <p>Culpa veniam voluptate ad eu non pariatur nostrud tempor qui dolore minim aliqua adipisicing. Id ullamco sit ipsum minim dolore magna occaecat. Anim eiusmod elit occaecat tempor irure reprehenderit anim sit elit eu. Eu enim sint ut aliqua do quis in sit.</p>
            </div>
        );
    }
}

export default AboutPage;